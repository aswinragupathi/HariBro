import { HttpClient } from "@angular/common/http";
import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  title = "ESG";
  dataList: any = [];
  _name: string;
  constructor(public _http: HttpClient) {
    this._name = "";
    this._http
      .get("https://mocki.io/v1/d4867d8b-b5d5-4a48-a4ab-79131b5809b8")
      .subscribe((data) => {
        let _data = data;
        this.dataList = _data;
        // console.log("this.dataList ", _data);
      });
  }

  submit(name) {
    console.log("_name ", name);
    let payload = {
      name: "morpheus",
      job: "leader"
    };
    this._http.post("https://reqres.in/api/users", payload).subscribe((res) => {
      console.log("res ", res);
    });
  }
}
